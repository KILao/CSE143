# CSE143

Use the command lines in commandLines.txt to check the results.
The files for the data must be in the "A1-Data" directory, and that directoy must be
in the same directory as ngrams.py